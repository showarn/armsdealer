fx_version 'cerulean'
game 'gta5'

author 'Ditt namn'
description 'Arms Dealer System med Crafting, XP och Rank'
version '1.0.0'

-- 🔥 Beroenden
dependency 'qb-core'

-- 🛠 Gemensam konfig
shared_scripts {
    'config.lua',
    'shared/rankutils.lua' -- 👈 Lägg till detta
}


-- 🔥 Server-scripts
server_scripts {
    'server/main.lua',
    'server/crafting.lua',
    'server/expsystem.lua', -- 🧠 XP-system
    'server/smuggling.lua',
}

-- 🎮 Klient-scripts
client_scripts {
    'client/main.lua',
    'client/crafting.lua',
    'client/expsystem.lua', -- 🧠 XP-system
    'client/smuggling.lua', 
}

-- 🖥 UI
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/styles.css',
    'html/script.js',
    'html/loot.mp3',
    'html/svets.mp3',

    -- 🔫 Bilder för loot
    'html/img/metalscrap.png',
    'html/img/steel.png',
    'html/img/copper.png',
    'html/img/ironoxide.png',
    'html/img/aluminumoxide.png',
    'html/img/iron.png',
    'html/img/default.png'
}

-- ✅ Lua 5.4 stöd
lua54 'yes'

-- 📂 client/expsystem.lua

local QBCore = exports['qb-core']:GetCoreObject()
local playerXP = 0
local playerRank = "Rookie Smuggler"

RegisterNetEvent('qb-armsdealer:client:SetXP', function(xp, rank)
    local previousRank = playerRank -- ⛳️ Spara föregående rank innan vi uppdaterar

    playerXP = xp
    playerRank = rank

    -- 🖥️ Uppdatera UI med nya XP och rank
    SendNUIMessage({
        action = 'updateXP',
        xp = xp,
        rank = rank
    })

    -- 🏆 Om ranken har ändrats → visa rank-up popup
    if rank ~= previousRank then
        TriggerEvent("qb-armsdealer:client:ShowRankUp", rank)
    end
end)

RegisterNetEvent("qb-armsdealer:client:ShowRankUp", function(rank)
    -- 🏆 Visa popup om rank-up
    SendNUIMessage({
        action = "showRankUp",
        rank = rank,
        unlocked = GetUnlockedWeaponsForRank(rank)
    })
end)

-- 🔓 Hämta recept som låses upp vid denna rank (client-version)
function GetUnlockedWeaponsForRank(rank)
    local unlocked = {}
    local xp = playerXP
    local currentRankIndex = GetPlayerRankIndex(xp)

    for _, recipe in ipairs(Config.CraftingRecipes) do
        if recipe.requiredRankIndex == currentRankIndex then
            table.insert(unlocked, recipe.label)
        end
    end

    return unlocked
end


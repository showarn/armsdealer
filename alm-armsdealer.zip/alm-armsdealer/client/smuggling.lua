-- BLOCK 1/5: INIT, STATUS, FAS 1–2 (BIL & USB)

local QBCore = exports['qb-core']:GetCoreObject()

-- STATUSVARIABLER
local isActiveSmuggler = false
local smugglerServerId = nil
local currentHeist = nil
local smugglingPhase = 0

local spawnedNPCs, usbGuards = {}, {}
local keyPickupActive, keyGiven, isNearKey, keyPromptAlreadyShown = false, false, false, false
local tiedNpcSpawned, usbTaken, canInteractWithHostage = false, false, false
local tiedNpc, armoryNpc, lootBox, lootTruck = nil, nil, nil, nil
local armoryInteracted = false
local spawnedCar = nil
local currentBlip = nil
local lootDeliveryZone = nil

-- RELATIONSGRUPP
AddRelationshipGroup("SMUGGLING_GUARD")
SetRelationshipBetweenGroups(0, `SMUGGLING_GUARD`, `SMUGGLING_GUARD`)
SetRelationshipBetweenGroups(5, `SMUGGLING_GUARD`, `PLAYER`)
SetRelationshipBetweenGroups(5, `PLAYER`, `SMUGGLING_GUARD`)

-- NOTIFIER
RegisterNetEvent("smuggling:client:ShowXPReward", function(amount)
    SendNUIMessage({ action = "notify", type = "xp", message = "Du fick " .. amount .. " XP!" })
end)

-- DEBUG KOMMANDO
RegisterCommand("skipsmuggling", function()
    if smugglingPhase == 0 then StartUSBPhase()
    elseif smugglingPhase == 1 then SpawnTiedNpc()
    elseif smugglingPhase == 2 then StartArmory()
    elseif smugglingPhase == 3 then StartWarehouseCombat()
    elseif smugglingPhase == 4 then StartLootDelivery()
    end
end)

-- NOLLSTÄLLNING
function CleanupSmuggling()
    for _, ped in ipairs(spawnedNPCs) do if DoesEntityExist(ped) then DeleteEntity(ped) end end
    for _, ped in ipairs(usbGuards) do if DoesEntityExist(ped) then DeleteEntity(ped) end end
    if DoesEntityExist(tiedNpc) then DeleteEntity(tiedNpc) end
    if DoesEntityExist(spawnedCar) then DeleteVehicle(spawnedCar) end
    if DoesEntityExist(lootBox) then DeleteObject(lootBox) end
    if DoesEntityExist(lootTruck) then DeleteVehicle(lootTruck) end
    if currentBlip and DoesBlipExist(currentBlip) then RemoveBlip(currentBlip) end
    isActiveSmuggler = false
    smugglingPhase = 0
    currentHeist = nil
    keyPickupActive, keyGiven, isNearKey, keyPromptAlreadyShown = false, false, false, false
    tiedNpcSpawned, usbTaken, canInteractWithHostage = false, false, false
end

RegisterNetEvent("smuggling:client:forceAbortHeist", function()
    CleanupSmuggling()
    SendNUIMessage({ action = "notify", type = "error", message = "Smugglingsuppdraget avbröts." })
end)

CreateThread(function()
    while true do
        Citizen.Wait(1000)
        if isActiveSmuggler then
            if IsEntityDead(PlayerPedId()) or (spawnedCar and not IsVehicleDriveable(spawnedCar, false)) then
                TriggerServerEvent("smuggling:server:endHeist")
                CleanupSmuggling()
            end
        end
    end
end)

RegisterNetEvent("smuggling:client:startHeist", function(heistData)
    isActiveSmuggler = true
    smugglerServerId = GetPlayerServerId(PlayerId())
    currentHeist = heistData
    smugglingPhase = 0
    StartCarPhase()
end)

function StartCarPhase()
    local carModel = GetHashKey(Config.SmugglingHeist.CarModel or "rebel")
    RequestModel(carModel)
    while not HasModelLoaded(carModel) do Citizen.Wait(10) end

    spawnedCar = CreateVehicle(carModel, currentHeist.carPos, currentHeist.carHeading, true, true)
    SetEntityAsMissionEntity(spawnedCar, true, true)
    SetVehicleDoorsLocked(spawnedCar, 2)
    local plate = "SMUG" .. tostring(math.random(1000, 9999))
    SetVehicleNumberPlateText(spawnedCar, plate)
    currentHeist.carPlate = plate
    currentHeist.carNetId = NetworkGetNetworkIdFromEntity(spawnedCar)
    SetNetworkIdCanMigrate(currentHeist.carNetId, true)

    currentBlip = AddBlipForEntity(spawnedCar)
    SetBlipSprite(currentBlip, 225)
    SetBlipColour(currentBlip, 5)
    SetBlipScale(currentBlip, 0.9)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Stulen Bil")
    EndTextCommandSetBlipName(currentBlip)

    for _, npc in ipairs(currentHeist.npcs) do
        local ped = SpawnSmugglerNPC(npc.model, npc.pos, npc.heading, npc.weapon)
        table.insert(spawnedNPCs, ped)
    end

    SendNUIMessage({ action = "showPopup", text = "Två vakter bevakar bilen – eliminera dem och ta nycklarna." })

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(500)
            if not keyPickupActive and #spawnedNPCs > 0 then
                local dead = 0
                for _, ped in ipairs(spawnedNPCs) do if IsEntityDead(ped) then dead += 1 end end
                if dead == #spawnedNPCs and not keyPromptAlreadyShown then
                    keyPromptAlreadyShown, keyPickupActive = true, true
                    keyTargetPed = spawnedNPCs[math.random(1, #spawnedNPCs)]
                    SendNUIMessage({ action = "showPopup", text = "Sök kropparna efter bilnycklar..." })
                end
            end
        end
    end)

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
            if keyPickupActive and keyTargetPed and not keyGiven then
                local coords = GetEntityCoords(keyTargetPed)
                local pCoords = GetEntityCoords(PlayerPedId())
                if #(coords - pCoords) < 2.0 then
                    if not isNearKey then
                        isNearKey = true
                        SendNUIMessage({ action = "showKeyPrompt", show = true, text = "[E] Söker kroppen efter bilnycklar..." })
                    end
                    if IsControlJustReleased(0, 38) then
                        keyGiven = true
                        SendNUIMessage({ action = "showKeyPrompt", show = false })
                        QBCore.Functions.Progressbar("pickup_keys", "Plockar upp nycklar...", 3000, false, true, {}, {}, {}, {}, function()
                            TriggerEvent("vehiclekeys:client:SetOwner", currentHeist.carPlate)
                            TriggerServerEvent("qb-vehiclekeys:server:GiveTemporaryKey", currentHeist.carPlate, currentHeist.carNetId)
                            if currentBlip and DoesBlipExist(currentBlip) then RemoveBlip(currentBlip) end
                            smugglingPhase = 1
                            StartUSBPhase()
                        end)
                    end
                elseif isNearKey then
                    isNearKey = false
                    SendNUIMessage({ action = "showKeyPrompt", show = false })
                end
            end
        end
    end)
end

-- BLOCK 2/5: USB-MISSION, GISSLAN, ARMORY

function StartUSBPhase()
    smugglingPhase = 1
    usbGuards = {}
    local loc = Config.USBMission.location
    currentBlip = AddBlipForCoord(loc)
    SetBlipSprite(currentBlip, 568)
    SetBlipColour(currentBlip, 5)
    SetBlipScale(currentBlip, 1.0)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Mötesplats: Lagerlokal")
    EndTextCommandSetBlipName(currentBlip)

    for _, pos in pairs(Config.USBMission.npcPositions) do
        local ped = SpawnSmugglerNPC(Config.USBMission.npcModel, pos, 0.0, Config.USBMission.npcWeapon)
        table.insert(usbGuards, ped)
    end

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1000)
            local alive = 0
            for _, ped in pairs(usbGuards) do
                if ped and not IsEntityDead(ped) then alive += 1 end
            end
            if alive == 0 and not tiedNpcSpawned then
                tiedNpcSpawned = true
                SendNUIMessage({ action = "notify", type = "success", message = "Alla vakter är döda. Rädda gisslan." })
                if currentBlip and DoesBlipExist(currentBlip) then RemoveBlip(currentBlip) end
                smugglingPhase = 2
                SpawnTiedNpc()
                break
            end
        end
    end)
end

function SpawnTiedNpc()
    local cfg = Config.USBMission
    RequestModel(cfg.tiedNpcModel)
    while not HasModelLoaded(cfg.tiedNpcModel) do Citizen.Wait(10) end

    tiedNpc = CreatePed(4, cfg.tiedNpcModel, cfg.tiedNpcPos.x, cfg.tiedNpcPos.y, cfg.tiedNpcPos.z - 1, cfg.tiedNpcPos.w, false, true)
    FreezeEntityPosition(tiedNpc, true)
    SetEntityInvincible(tiedNpc, true)
    SetBlockingOfNonTemporaryEvents(tiedNpc, true)

    RequestAnimDict("rcmextreme3")
    while not HasAnimDictLoaded("rcmextreme3") do Citizen.Wait(10) end
    TaskPlayAnim(tiedNpc, "rcmextreme3", "idle", 8.0, -8.0, -1, 1, 0, false, false, false)

    canInteractWithHostage = true
    local interactionShown = false

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
            if not tiedNpc or not DoesEntityExist(tiedNpc) then return end
            local dist = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(tiedNpc))
            if dist < 2.0 and canInteractWithHostage then
                if not interactionShown then
                    ShowInteraction("Knyt upp mannen (håll [E])")
                    interactionShown = true
                end
                if IsControlJustReleased(0, 38) then
                    canInteractWithHostage = false
                    ClearInteraction()
                    interactionShown = false
                    QBCore.Functions.Progressbar("free_hostage", "Räddar gisslan...", 3000, false, true, {}, {}, {}, {}, function()
                        ClearPedTasks(tiedNpc)
                        FreezeEntityPosition(tiedNpc, false)
                        SendNUIMessage({ action = "notify", type = "info", message = "Vi måste till armory, följ mig!" })
                        Citizen.Wait(1000)

                        FollowPlayer()

                        -- Sätt igång loop som ser till att NPC hoppar in/ur bilen med spelaren
                        Citizen.CreateThread(function()
                            while DoesEntityExist(tiedNpc) do
                                Citizen.Wait(1000)
                                local ped = PlayerPedId()
                                local veh = GetVehiclePedIsIn(ped, false)

                                if veh and not IsPedInVehicle(tiedNpc, veh, false) then
                                    -- Spelaren är i fordon, NPC är inte – försök sätta in NPC
                                    for seat = 0, GetVehicleMaxNumberOfPassengers(veh) - 1 do
                                        if IsVehicleSeatFree(veh, seat) then
                                            TaskEnterVehicle(tiedNpc, veh, -1, seat, 2.0, 1, 0)
                                            break
                                        end
                                    end
                                elseif not veh and IsPedInAnyVehicle(tiedNpc, false) then
                                    -- Spelaren har lämnat fordon – tvinga NPC att lämna också
                                    TaskLeaveVehicle(tiedNpc, GetVehiclePedIsIn(tiedNpc, false), 0)
                                    FollowPlayer()
                                end
                            end
                        end)

                        smugglingPhase = 3
                        StartArmory()
                    end, function()
                        canInteractWithHostage = true
                        ShowInteraction("Knyt upp mannen (håll [E])")
                        interactionShown = true
                    end)
                end
            elseif dist >= 2.0 and interactionShown then
                ClearInteraction()
                interactionShown = false
            end
        end
    end)
end

function FollowPlayer()
    if DoesEntityExist(tiedNpc) then
        TaskFollowToOffsetOfEntity(tiedNpc, PlayerPedId(), 0.0, 1.0, 0.0, 2.0, -1, 1.0, true)
    end
end


function StartArmory()
    local cfg = Config.USBMission
    armoryInteracted = false
    RequestModel(`s_m_y_blackops_01`)
    while not HasModelLoaded(`s_m_y_blackops_01`) do Citizen.Wait(10) end

    armoryNpc = CreatePed(4, `s_m_y_blackops_01`, cfg.armoryPos.x, cfg.armoryPos.y, cfg.armoryPos.z - 1, cfg.armoryPos.w or 0.0, false, true)
    SetEntityInvincible(armoryNpc, true)
    SetBlockingOfNonTemporaryEvents(armoryNpc, true)
    FreezeEntityPosition(armoryNpc, true)

    currentBlip = AddBlipForCoord(cfg.armoryPos)
    SetBlipSprite(currentBlip, 110)
    SetBlipColour(currentBlip, 3)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Armory Station")
    EndTextCommandSetBlipName(currentBlip)

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
            if not DoesEntityExist(armoryNpc) then return end
            local player = PlayerPedId()
            local dist = #(GetEntityCoords(player) - GetEntityCoords(armoryNpc))
            if dist < 2.0 and not armoryInteracted then
                ShowInteraction("Tryck [E] för att ta emot utrustning")
                if IsControlJustReleased(0, 38) then
                    armoryInteracted = true
                    ClearInteraction()
                    RequestAnimDict("anim@heists@ornate_bank@grab_cash")
                    while not HasAnimDictLoaded("anim@heists@ornate_bank@grab_cash") do Citizen.Wait(10) end
                    TaskPlayAnim(player, "anim@heists@ornate_bank@grab_cash", "grab", 8.0, -8.0, 2000, 0, 0, false, false, false)
                    Citizen.Wait(2000)
                    GiveWeaponToPed(tiedNpc, GetHashKey("weapon_smg"), 120, true, true)
                    SetPedArmour(PlayerPedId(), 100)
                    SendNUIMessage({ action = "notify", type = "info", message = "Din kontakt har fått en SMG och är redo." })
                    if currentBlip and DoesBlipExist(currentBlip) then RemoveBlip(currentBlip) end
                    smugglingPhase = 4
                    StartWarehouseCombat()
                end
            elseif dist >= 2.0 and not armoryInteracted then
                ClearInteraction()
            end
        end
    end)
end

-- BLOCK 3/5: LAGERSTRID, LÅDA, FÖRSTA GAFFELTRUCKEN

function StartWarehouseCombat()
    local cfg = Config.WarehouseCombat
    currentBlip = AddBlipForCoord(cfg.location)
    SetBlipSprite(currentBlip, 437)
    SetBlipColour(currentBlip, 1)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Lagerlokal")
    EndTextCommandSetBlipName(currentBlip)

    local warehouseEnemies = {}
    for _, pos in ipairs(cfg.enemyPositions) do
        local ped = SpawnSmugglerNPC(cfg.enemyModel, pos, 0.0, cfg.enemyWeapon)
        table.insert(warehouseEnemies, ped)
    end

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1000)
            local alive = 0
            for _, ped in ipairs(warehouseEnemies) do
                if ped and not IsEntityDead(ped) then alive += 1 end
            end
            if alive == 0 then
                if currentBlip and DoesBlipExist(currentBlip) then RemoveBlip(currentBlip) end
                SendNUIMessage({ action = "notify", type = "success", message = "Alla vakter är döda. Hämta vapenlådan." })
                smugglingPhase = 5
                SpawnWeaponCrate()
                break
            end
        end
    end)
end

function SpawnWeaponCrate()
    local cfg = Config.WeaponCrate

    -- Spawn weapon crate
    RequestModel(cfg.model)
    while not HasModelLoaded(cfg.model) do Citizen.Wait(10) end
    lootBox = CreateObject(GetHashKey(cfg.model), cfg.pos.x, cfg.pos.y, cfg.pos.z - 1.0, true, true, false)
    PlaceObjectOnGroundProperly(lootBox)
    FreezeEntityPosition(lootBox, true)

    -- Spawn gaffeltruck
    local model = GetHashKey(cfg.forkliftModel)
    RequestModel(model)
    while not HasModelLoaded(model) do Citizen.Wait(10) end

    lootTruck = CreateVehicle(model, cfg.forkliftSpawn, cfg.forkliftHeading, true, true)
    SetEntityAsMissionEntity(lootTruck, true, true)

    local plate = "GAFF" .. tostring(math.random(1000, 9999))
    SetVehicleNumberPlateText(lootTruck, plate)
    SetVehicleDoorsLocked(lootTruck, 1)

    local netId = NetworkGetNetworkIdFromEntity(lootTruck)
    SetNetworkIdCanMigrate(netId, true)

    -- Ge nycklar
    TriggerEvent("vehiclekeys:client:SetOwner", plate)
    TriggerServerEvent("qb-vehiclekeys:server:GiveTemporaryKey", plate, netId)

    -- Blip för vapenlåda
    currentBlip = AddBlipForEntity(lootBox)
    SetBlipSprite(currentBlip, 478)
    SetBlipColour(currentBlip, 5)
    SetBlipScale(currentBlip, 1.0)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Vapenlåda")
    EndTextCommandSetBlipName(currentBlip)

    SendNUIMessage({ action = "notify", type = "info", message = "Använd gaffeltrucken för att lyfta upp lådan och lasta på pickupen." })

    -- Kolla om lådan är upplyft
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1000)
            if not DoesEntityExist(lootBox) then return end

            local crateCoords = GetEntityCoords(lootBox)
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            if vehicle and GetEntityModel(vehicle) == model then
                local liftCoords = GetEntityCoords(vehicle)
                local dist = #(liftCoords - crateCoords)

                if dist < 3.0 and IsEntityAttachedToEntity(lootBox, vehicle) then
                    SendNUIMessage({ action = "notify", type = "success", message = "Lådan är på trucken. Leverera till avlämningsplats." })
                    smugglingPhase = 6
                    StartLootDelivery()
                    break
                end
            end
        end
    end)
end


-- BLOCK 4/5: LEVERANSZON, ANDRA FORKLIFT, SLÄPPMARKER

function StartLootDelivery()
    local cfg = Config.LootDelivery
    local garage = cfg.garagePos

    -- Blip till leveranszon
    currentBlip = AddBlipForCoord(garage)
    SetBlipSprite(currentBlip, 473)
    SetBlipColour(currentBlip, 2)
    SetBlipScale(currentBlip, 1.0)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Leveransplats")
    EndTextCommandSetBlipName(currentBlip)

    -- Spawn andra forklift
    local model = GetHashKey(cfg.forkliftModel)
    RequestModel(model)
    while not HasModelLoaded(model) do Citizen.Wait(10) end

    local deliveryForklift = CreateVehicle(model, cfg.forkliftSpawn, cfg.forkliftHeading, true, true)
    SetEntityAsMissionEntity(deliveryForklift, true, true)

    local plate = "AVLS" .. tostring(math.random(1000, 9999))
    SetVehicleNumberPlateText(deliveryForklift, plate)
    SetVehicleDoorsLocked(deliveryForklift, 1)

    local netId = NetworkGetNetworkIdFromEntity(deliveryForklift)
    SetNetworkIdCanMigrate(netId, true)

    TriggerEvent("vehiclekeys:client:SetOwner", plate)
    TriggerServerEvent("qb-vehiclekeys:server:GiveTemporaryKey", plate, netId)

    -- Zonkoll
    local zoneCenter = cfg.dropZone
    local zoneRadius = 3.0
    local shownHelp = false

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1000)
            if lootBox and not IsEntityAttachedToAnyVehicle(lootBox) then
                local crateCoords = GetEntityCoords(lootBox)
                local dist = #(crateCoords - zoneCenter)
                if dist < zoneRadius then
                    if not shownHelp then
                        SendNUIMessage({ action = "notify", type = "success", message = "Lådan levererad. Belöning utdelas..." })
                        shownHelp = true
                    end
                    TriggerServerEvent("smuggling:server:GiveLootReward")
                    CleanupSmuggling()
                    break
                end
            end
        end
    end)
end


-- BLOCK 5/5: LOOTBELÖNING, HELPERS, INTERACTION

-- HJÄLPFUNKTIONER
function SpawnSmugglerNPC(model, coords, heading, weapon)
    RequestModel(model)
    while not HasModelLoaded(model) do Citizen.Wait(10) end

    local ped = CreatePed(4, model, coords.x, coords.y, coords.z - 1.0, heading or 0.0, true, true)
    GiveWeaponToPed(ped, GetHashKey(weapon), 250, false, true)
    SetPedCombatAttributes(ped, 46, true)
    SetPedAccuracy(ped, 60)
    SetPedRelationshipGroupHash(ped, GetHashKey("SMUGGLING_GUARD"))
    SetEntityAsMissionEntity(ped, true, true)
    SetPedAsEnemy(ped, true)
    TaskCombatPed(ped, PlayerPedId(), 0, 16)

    Citizen.CreateThread(function()
        while not IsEntityDead(ped) do Citizen.Wait(250) end
        Citizen.Wait(250)
        TriggerServerEvent("smuggling:server:RewardKillXP")
    end)

    return ped
end

function ShowInteraction(text)
    SendNUIMessage({ action = "interaction", display = true, text = text })
end

function ClearInteraction()
    SendNUIMessage({ action = "interaction", display = false })
end

-- LOOT-KLAR
-- Detta triggas från server när loot delas ut
RegisterNetEvent("smuggling:client:ReceiveLoot", function(items)
    local text = "Du fick: " .. table.concat(items, ", ")
    SendNUIMessage({ action = "notify", type = "loot", message = text })
end)

-- SLUT PÅ FILEN
-- ✅ HELA SYSTEMET KLART
-- ✅ 8 FASER FULLFÖLJDA
-- ✅ NUI + XP + INTERACTION + BLIPS + AI + GAFFELTRUCK
-- ✅ REDO FÖR TEST OCH SERVERDEL

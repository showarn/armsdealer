local QBCore = exports['qb-core']:GetCoreObject()
local weldingProps = {
    torch = nil,
    mask = nil,
    particle = nil
}

local function startWeldingProps()
    local ped = PlayerPedId()

    local maskModel = `prop_welding_mask_01`
    RequestModel(maskModel)
    while not HasModelLoaded(maskModel) do Wait(0) end

    weldingProps.mask = CreateObject(maskModel, GetEntityCoords(ped), true, true, true)

    AttachEntityToEntity(
        weldingProps.mask,
        ped,
        GetPedBoneIndex(ped, 31086),
        0.120, 0.020, 0.000,
        1.0, 88.0, 180.0,
        true, true, false, true, 1, true
    )

    local torchModel = `prop_weld_torch`
    RequestModel(torchModel)
    while not HasModelLoaded(torchModel) do Wait(0) end

    weldingProps.torch = CreateObject(torchModel, GetEntityCoords(ped), true, true, true)

    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do Wait(0) end

    UseParticleFxAssetNextCall("core")
    weldingProps.particle = StartParticleFxLoopedOnEntity(
        "ent_sparking_wires",
        weldingProps.torch,
        0.0, 0.0, 0.1,
        0.0, 0.0, 0.0,
        1.0,
        false, false, false
    )

    SendNUIMessage({ action = "playWeldSound" })
end

local function raiseWeldingMask()
    if not weldingProps.mask then return end

    local ped = PlayerPedId()
    RequestAnimDict("missheistdockssetup1clipboard@base")
    while not HasAnimDictLoaded("missheistdockssetup1clipboard@base") do Wait(0) end

    TaskPlayAnim(ped, "missheistdockssetup1clipboard@base", "base", 8.0, -8.0, 1500, 49, 0, false, false, false)

    AttachEntityToEntity(
        weldingProps.mask,
        ped,
        GetPedBoneIndex(ped, 31086),
        0.130, 0.020, 0.000,       -- ✔ Uppdaterad position
        -63.0, 89.0, 180.0,        -- ✔ Uppdaterad rotation
        true, true, false, true, 1, true
    )

    Wait(2000)
end

local function stopWeldingProps()
    if weldingProps.particle then
        StopParticleFxLooped(weldingProps.particle, 0)
        weldingProps.particle = nil
    end
    if weldingProps.torch then
        DeleteEntity(weldingProps.torch)
        weldingProps.torch = nil
    end
    if weldingProps.mask then
        DeleteEntity(weldingProps.mask)
        weldingProps.mask = nil
    end

    SendNUIMessage({ action = "stopWeldSound" })
end

RegisterNUICallback("openCrafting", function(_, cb)
    TriggerServerEvent("armsdealer:server:openCrafting")
    cb("ok")
end)

RegisterNUICallback("startCrafting", function(data, cb)
    local recipeIndex = data.index
    local recipe = Config.CraftingRecipes[recipeIndex]
    if not recipe then
        QBCore.Functions.Notify("Ogiltigt recept!", "error")
        return cb("error")
    end

    if Config.UseCraftingZone then
        local playerCoords = GetEntityCoords(PlayerPedId())
        local dist = #(playerCoords - Config.CraftingZone.coords)
        if dist > Config.CraftingZone.radius then
            QBCore.Functions.Notify("Du måste vara vid vapenverkstaden för att tillverka!", "error")
            return cb("error")
        end
    end

    -- 🔒 Kontrollera att spelaren har materialen innan tillverkning
    local playerItems = QBCore.Functions.GetPlayerData().items or {}
    for material, requiredAmount in pairs(recipe.materials) do
        local has = 0
        for _, item in pairs(playerItems) do
            if item.name == material then
                has = item.amount or 0
                break
            end
        end
        if has < requiredAmount then
            QBCore.Functions.Notify("Du saknar material: " .. material, "error")
            return cb("error")
        end
    end

    SetNuiFocus(false, false)

    local ped = PlayerPedId()

    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_WELDING", 0, true)
    startWeldingProps()

    TriggerEvent('progressbar:client:progress', {
        name = "crafting_weapon",
        duration = recipe.craftingTime * 1000,
        label = "Tillverkar " .. recipe.label .. "...",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true
        },
    }, function(cancelled)
        ClearPedTasks(ped)
        raiseWeldingMask()
        stopWeldingProps()

        if not cancelled then
            TriggerServerEvent("armsdealer:server:completeCraft", recipeIndex)
        else
            QBCore.Functions.Notify("Tillverkning avbruten.", "error")
        end
    end)

    cb("ok")
end)

RegisterNetEvent("armsdealer:client:openCrafting", function(xp)
    local rankIndex = GetPlayerRankIndex(xp)
    local recipes = {}

    for i, recipe in ipairs(Config.CraftingRecipes) do
        if rankIndex >= recipe.requiredRankIndex then
            table.insert(recipes, {
                index = i,
                label = recipe.label,
                materials = recipe.materials
            })
        end
    end

    SendNUIMessage({
        action = "openCrafting",
        recipes = recipes
    })

    SetNuiFocus(true, true)
end)
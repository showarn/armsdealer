-- 📂 client/main.lua (REFACTORED - XP & RANK flyttat till expsystem.lua och ranks.lua)
QBCore = exports['qb-core']:GetCoreObject()

-- Hämta config
local jobName = Config.JobName or "armsdealer"

local isPickingUp = false
local isDelivering = false
local pickupBlip = nil
local dropoffBlip = nil
local currentPickupCoords = nil
local currentDropoffCoords = nil
local spawnedBag = nil
local spawnedDropoffBag = nil
local playerBag = nil
local isMissionActive = false

RegisterNUICallback('closeMenu', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('restorePlayerControl', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNetEvent('qb-armsdealer:openArmsDealerMenu', function(xp, rank)
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'openMenu',
        xp = xp,
        rank = rank
    })
end)

RegisterNUICallback('fetchParts', function(data, cb)
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData.job.name ~= jobName then
        QBCore.Functions.Notify("Du är inte en arms dealer!", "error")
        cb("error")
        return
    end
    if isMissionActive then
        QBCore.Functions.Notify("Du har redan ett aktivt uppdrag!", "error")
        cb("error")
        return
    end
    isMissionActive = true
    TriggerServerEvent('alm-armsdealer:server:StartPartRun')
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('smuggleGuns', function(data, cb)
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData.job.name ~= Config.JobName then
        QBCore.Functions.Notify("Du är inte en arms dealer!", "error")
        cb("error")
        return
    end

    if isMissionActive then
        QBCore.Functions.Notify("Du har redan ett aktivt uppdrag!", "error")
        cb("error")
        return
    end

    isMissionActive = true
    TriggerServerEvent("armsdealer:server:startSmuggleHeist")
    SetNuiFocus(false, false)
    cb("ok")
end)

-- 📦 Spawn pickup-väska
RegisterNetEvent('alm-armsdealer:client:SetPickupLocation', function(coords)
    if pickupBlip then RemoveBlip(pickupBlip) end

    pickupBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(pickupBlip, 568)
    SetBlipRoute(pickupBlip, true)
    SetBlipColour(pickupBlip, 5)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Pickup: Vapendelar")
    EndTextCommandSetBlipName(pickupBlip)

    local bagModel = `prop_cs_heist_bag_02`
    RequestModel(bagModel)
    while not HasModelLoaded(bagModel) do Wait(10) end

    local x, y, z = coords.x, coords.y, coords.z + 20.0
    local success, groundZ = GetGroundZFor_3dCoord(x, y, z, false)
    if not success then groundZ = coords.z end

    spawnedBag = CreateObject(bagModel, x, y, groundZ + 0.05, false, true, false)
    PlaceObjectOnGroundProperly(spawnedBag)
    FreezeEntityPosition(spawnedBag, true)

    currentPickupCoords = vector3(x, y, groundZ)
    isPickingUp = true
    QBCore.Functions.Notify("Åk till markerad plats för att hämta vapendelar!", "primary")
end)

-- 📦 Spawn dropoff-väska
RegisterNetEvent('alm-armsdealer:client:SetDropoffLocation', function(coords)
    if dropoffBlip then RemoveBlip(dropoffBlip) end

    dropoffBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(dropoffBlip, 501)
    SetBlipRoute(dropoffBlip, true)
    SetBlipColour(dropoffBlip, 2)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Leverans: Vapendelar")
    EndTextCommandSetBlipName(dropoffBlip)

    local bagModel = `prop_cs_heist_bag_02`
    RequestModel(bagModel)
    while not HasModelLoaded(bagModel) do Wait(10) end

    local x, y, z = coords.x, coords.y, coords.z + 20.0
    local success, groundZ = GetGroundZFor_3dCoord(x, y, z, false)
    if not success then groundZ = coords.z end

    spawnedDropoffBag = CreateObject(bagModel, x, y, groundZ + 0.05, false, true, false)
    PlaceObjectOnGroundProperly(spawnedDropoffBag)
    FreezeEntityPosition(spawnedDropoffBag, true)

    currentDropoffCoords = vector3(x, y, groundZ)
    isDelivering = true
    QBCore.Functions.Notify("Åk till markerad plats för att lämna vapendelar!", "success")
end)

-- 🧠 Tick för pickup/dropoff interaktion
CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        if isPickingUp and currentPickupCoords then
            if #(coords - currentPickupCoords) < 2.5 then
                DrawText3D(currentPickupCoords.x, currentPickupCoords.y, currentPickupCoords.z + 1.0, "[E] Plocka upp Vapendelar")
                if IsControlJustReleased(0, 38) then
                    isPickingUp = false
                    if pickupBlip then RemoveBlip(pickupBlip) end
                    TriggerServerEvent('alm-armsdealer:server:PickupPart')
                    TriggerEvent('alm-armsdealer:client:GiveBackpack')
                    if spawnedBag then DeleteObject(spawnedBag) end
                end
            end
        end

        if isDelivering and currentDropoffCoords then
            if #(coords - currentDropoffCoords) < 2.5 then
                DrawText3D(currentDropoffCoords.x, currentDropoffCoords.y, currentDropoffCoords.z + 1.0, "[E] Lämna Vapendelar")
                if IsControlJustReleased(0, 38) then
                    isDelivering = false
                    if dropoffBlip then RemoveBlip(dropoffBlip) end
                    TriggerServerEvent('alm-armsdealer:server:CompleteRun')
                    if spawnedDropoffBag then DeleteObject(spawnedDropoffBag) end
                    if playerBag then DeleteObject(playerBag) end
                    isMissionActive = false
                end
            end
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = string.len(text) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 75)
end

RegisterNetEvent('alm-armsdealer:client:GiveBackpack', function()
    local ped = PlayerPedId()
    local model = `prop_cs_heist_bag_02`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end

    playerBag = CreateObject(model, GetEntityCoords(ped), true, true, false)
    AttachEntityToEntity(playerBag, ped, GetPedBoneIndex(ped, 24818), 0.1, -0.11, 0.08, 0.0, 90.0, 175.0, true, true, false, true, 1, true)
end)

RegisterNetEvent('alm-armsdealer:client:RemoveBackpack', function()
    if playerBag then
        DeleteObject(playerBag)
        playerBag = nil
    end
end)

RegisterNetEvent('alm-armsdealer:client:ShowRewardNotification', function(rewards)
    SendNUIMessage({
        action = 'showReward',
        rewards = rewards or {}
    })
end)
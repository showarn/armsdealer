// 📦 Arms Dealer - script.js - Full version med animationer, XP-bar, loot-notiser, tema och ljud

let currentXP = 0;
let maxXP = 30000; // Anpassa efter din balans

const weldAudio = new Audio("./svets.mp3");
weldAudio.loop = true;

window.addEventListener("message", function (event) {
  const data = event.data;

  if (data.action === "openMenu") {
    document.getElementById("arms-dealer-menu").classList.add("show");
    updateXP(data.xp, data.rank);
  }

  if (data.action === "updateXP") {
    updateXP(data.xp, data.rank);
  }

  if (data.action === "showReward") {
    showRewardNotification(data.rewards);
  }

  if (data.action === "openCrafting") {
    showCraftingMenu(data.recipes);
  }

  if (data.action === "playWeldSound") {
    weldAudio.volume = 0.65;
    weldAudio.play().catch(() => {});
  }

  if (data.action === "stopWeldSound") {
    weldAudio.pause();
    weldAudio.currentTime = 0;
  }

  // 🚀 NYTT: Rank-Up popup funktion
  if (data.action === "showRankUp") {
    showRankUpPopup(data.rank, data.unlocked);
  }

  // 🔔 Popup-meddelanden (t.ex. "Ta nycklar", "Du avbröt" etc.)
  if (data.action === "showPopup") {
    const box = document.getElementById("popup-box");
    if (box) {
      box.innerText = data.text;
      box.classList.add("show");
      setTimeout(() => {
        box.classList.remove("show");
      }, 4000);
    }
  }

  // 🔘 "[E] Ta nycklar"-prompt
  if (data.action === "showKeyPrompt") {
    const keyDiv = document.getElementById("key-interact");
    if (keyDiv) {
      if (data.show) {
        keyDiv.innerText = data.text;
        keyDiv.classList.add("show");
      } else {
        keyDiv.classList.remove("show");
      }
    }
  }

  // 🔔 NUI-notify typ "Sätter på utrustning..."
  if (data.action === "notify") {
    const box = document.getElementById("popup-box");
    if (box) {
      box.innerText = data.message || "Meddelande";
      box.classList.add("show");
      setTimeout(() => {
        box.classList.remove("show");
      }, 4000);
    }
  }

  if (data.action === "interaction") {
    const prompt = document.getElementById("key-interact");
    if (data.display) {
      prompt.innerText = data.text || "[E] Interagera";
      prompt.classList.add("show");
    } else {
      prompt.classList.remove("show");
    }
  }
});

// 🎯 XP- och rank-uppdatering med animation
function updateXP(xp, rank) {
  currentXP = xp;
  document.getElementById("xp-display").innerText = `XP: ${xp}`;
  document.getElementById("rank-display").innerText = `Rank: ${rank}`;

  const bar = document.getElementById("xp-bar");

  const thresholds = [
    { rank: "Rookie Smuggler", xp: 0 },
    { rank: "Street Supplier", xp: 500 },
    { rank: "Gun Hustler", xp: 1500 },
    { rank: "Black Market Trafficker", xp: 3000 },
    { rank: "Weapon Broker", xp: 5000 },
    { rank: "Cartel Associate", xp: 7500 },
    { rank: "Underground Kingpin", xp: 10000 },
    { rank: "Arms Syndicate Leader", xp: 14000 },
    { rank: "Warlord", xp: 18000 },
    { rank: "Black Market King", xp: 23000 },
    { rank: "MAX", xp: 30000 }
  ];

  let current = thresholds.find((t) => t.rank === rank);
  let currentIndex = thresholds.findIndex((t) => t.rank === rank);
  let next = thresholds[currentIndex + 1] || thresholds[currentIndex];

  let progress = 0;
  if (next.xp !== current.xp) {
    progress = (xp - current.xp) / (next.xp - current.xp);
  }

  progress = Math.max(0, Math.min(progress, 1));
  const targetWidth = progress * 100;
  bar.style.transition = 'width 0.5s ease-in-out';
  bar.style.width = `${targetWidth}%`;
}

// 🎉 Rank-up popup
function showRankUpPopup(rank, unlockedWeapons) {
  const popup = document.createElement("div");
  popup.className = "rankup-popup";
  popup.innerHTML = `
    <h2>Du har rankat upp till ${rank}!</h2>
    <p>Du har låst upp följande:</p>
    <ul>${unlockedWeapons.map(weapon => `<li>${weapon}</li>`).join("")}</ul>
  `;
  document.body.appendChild(popup);

  setTimeout(() => {
    popup.style.opacity = '0';
    setTimeout(() => popup.remove(), 500);
  }, 5000);
}

// 🎁 Belöningsnotiser med fade & ljud
function showRewardNotification(rewards) {
  if (!Array.isArray(rewards) || rewards.length === 0) return;

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.top = "20px";
  container.style.right = "20px";
  container.style.zIndex = "9999";
  container.style.display = "flex";
  container.style.flexDirection = "column";
  container.style.gap = "10px";

  rewards.forEach((r, i) => {
    setTimeout(() => {
      const box = document.createElement("div");
      box.style.background = "rgba(0, 0, 0, 0.85)";
      box.style.color = "#fff";
      box.style.padding = "10px 15px";
      box.style.borderRadius = "8px";
      box.style.boxShadow = "0 0 10px rgba(255,255,255,0.2)";
      box.style.display = "flex";
      box.style.alignItems = "center";
      box.style.minWidth = "220px";
      box.style.gap = "10px";
      box.style.opacity = 0;
      box.style.transition = "opacity 0.5s ease-in-out";

      const img = document.createElement("img");
      img.src = `img/${r.item}.png`;
      img.style.width = "32px";
      img.style.height = "32px";
      img.style.objectFit = "contain";
      img.onerror = () => { img.style.display = "none"; };

      const text = document.createElement("span");
      text.textContent = `+${r.amount} ${r.item}`;

      box.appendChild(img);
      box.appendChild(text);
      container.appendChild(box);
      document.body.appendChild(container);

      setTimeout(() => {
        box.style.opacity = 1;
        playLootSound();
      }, 50);

      setTimeout(() => {
        box.style.opacity = 0;
        setTimeout(() => box.remove(), 500);
      }, 5000);
    }, i * 400);
  });

  setTimeout(() => {
    if (container.parentNode) container.remove();
  }, rewards.length * 400 + 6000);
}

function playLootSound() {
  const audio = new Audio("loot.mp3");
  audio.volume = 0.3;
  audio.play().catch(() => {});
}

// 🔘 Knappinteraktioner & fetch-calls
document.getElementById("exit").addEventListener("click", function () {
  document.getElementById("arms-dealer-menu").classList.remove("show");
  fetch(`https://${GetParentResourceName()}/closeMenu`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
});

document.getElementById("fetch-parts").addEventListener("click", function () {
  fetch(`https://${GetParentResourceName()}/fetchParts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
  document.getElementById("arms-dealer-menu").classList.remove("show");
});

document.getElementById("theme-toggle").addEventListener("click", function () {
  const menu = document.getElementById("arms-dealer-menu");
  menu.classList.toggle("light-theme");
});

document.getElementById("buy-guns").addEventListener("click", function () {
  fetch(`https://${GetParentResourceName()}/openCrafting`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
});

document.getElementById("smuggle-guns").addEventListener("click", function () {
  fetch(`https://${GetParentResourceName()}/smuggleGuns`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
  document.getElementById("arms-dealer-menu").classList.remove("show");
});

document.getElementById("exit-crafting").addEventListener("click", () => {
  const menu = document.getElementById("arms-dealer-menu");
  menu.classList.remove("crafting-active");
  menu.classList.remove("show");

  fetch(`https://${GetParentResourceName()}/closeMenu`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({})
  });
});

function showCraftingMenu(recipes) {
  const menu = document.getElementById("arms-dealer-menu");
  const craftingSection = document.getElementById("crafting-section");
  const recipeList = document.getElementById("crafting-recipes");

  if (!menu || !craftingSection || !recipeList) return;

  recipeList.innerHTML = "";

  recipes.forEach((r) => {
    const li = document.createElement("li");
    li.dataset.index = r.index;

    const materialList = Object.entries(r.materials)
      .map(([item, amt]) => `${amt}x ${item}`)
      .join(", ");

    li.innerHTML = `<strong>${r.label}</strong><br><span>${materialList}</span>`;
    recipeList.appendChild(li);
  });

  menu.classList.add("crafting-active");

  recipeList.querySelectorAll("li").forEach((li) => {
    li.addEventListener("click", () => {
      const index = parseInt(li.dataset.index);

      menu.classList.remove("crafting-active");
      menu.classList.remove("show");

      fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({})
      });

      fetch(`https://${GetParentResourceName()}/startCrafting`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ index })
      });
    });
  });
}

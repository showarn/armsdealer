Config = {}

-- 🏆 Jobbinställningar
Config.JobName = "armsdealer"  -- Namnet på jobbet som spelaren kommer att få (Arms Dealer)
Config.JobLabel = "Arms Dealer"  -- Visningsnamn för jobbet (som det syns för spelaren)
Config.DefaultJobGrade = 0  -- Standardnivå för en Arms Dealer (kan vara 0 eller högre beroende på nivåer)

-- 💰 Priser för vapen (du kan justera dessa priser som du vill)
Config.GunPrices = {
    ["pistol"] = 1500,
    ["shotgun"] = 2500,
    ["smg"] = 3500,
    ["assault_rifle"] = 5000,
}

-- 🚨 Polisinformation
Config.PoliceAlertChance = 30  -- Chansen (i %) att polisen får en varning när smuggelaktiviteten pågår
Config.PoliceMarkerDuration = 60  -- Hur länge markerna ska vara synliga på kartan för polisen (i sekunder)

-- 🚚 Smuggelrutter
Config.SmugglingRoutes = {
    {start = vector3(200.0, 300.0, 50.0), destination = vector3(1000.0, 500.0, 30.0)},  
    {start = vector3(300.0, 400.0, 60.0), destination = vector3(1500.0, 700.0, 40.0)},  
}

-- 🔄 Dynamiska smuggelrutter (aktiveras dagligen)
Config.UpdateRoutesDaily = true  

-- 🏆 **XP & Rank System**
Config.RankThresholds = {
    { xp = 0, rank = "Rookie Smuggler" },
    { xp = 500, rank = "Street Supplier" },
    { xp = 1500, rank = "Gun Hustler" },
    { xp = 3000, rank = "Black Market Trafficker" },
    { xp = 5000, rank = "Weapon Broker" },
    { xp = 7500, rank = "Cartel Associate" },
    { xp = 10000, rank = "Underground Kingpin" },
    { xp = 15000, rank = "Arms Syndicate Leader" },
    { xp = 20000, rank = "Warlord" },
    { xp = 30000, rank = "Black Market King" }
}

-- 📈 Loot-ökning per rank (för varje ny rank +2% loot-chans)
Config.LootBonusPerRank = 2  -- Exempel: Om spelaren är rank 5, får de +10% extra loot

-- ⚠️ Riskinställningar för polisinblanding
Config.RiskIncreasePerAction = 5  -- Hur mycket risken ökar per smugglingstillfälle (%)
Config.PoliceSearchVehicleChance = 30  -- Chans (i %) att polisen genomsöker ett fordon
Config.MaxPoliceSearchTime = 30  -- Max tid (sekunder) för genomsökning av fordon

--------------------------------------------------------------------------------
-- 🏆 **Vapendels-run Inställningar**
--------------------------------------------------------------------------------

-- 📦 Pickup-platser för vapendelar (optimerade platser)
Config.PartPickupLocations = {
    vector3(1700.0, 3600.0, 34.0),   -- Exempelplats 1 (korrekt höjd)
    vector3(-600.0, 130.0, 57.0),    -- Exempelplats 2 (korrekt höjd)
    vector3(1090.5, -2000.2, 31.0),  -- Exempelplats 3 (korrekt höjd)
    vector3(-215.8, 6445.5, 31.5),   -- Exempelplats 4 (korrekt höjd)
    vector3(1200.0, -1400.0, 35.0),  -- Exempelplats 5 (korrekt höjd)
    vector3(-300.0, -1600.0, 31.0),  -- Exempelplats 6 (korrekt höjd)
}

-- 📍 Dropoff-platser för vapendelar (optimerade platser)
Config.PartDropoffLocations = {
    vector3(-1000.0, -2200.0, 13.0),   -- Exempelplats 1 (korrekt höjd)
    vector3(235.0, -1785.0, 28.0),     -- Exempelplats 2 (korrekt höjd)
    vector3(500.0, -1500.0, 29.0),     -- Exempelplats 3 (korrekt höjd)
    vector3(-800.0, 5400.0, 34.0),     -- Exempelplats 4 (korrekt höjd)
    vector3(1500.0, 3800.0, 34.0),     -- Exempelplats 5 (korrekt höjd)
    vector3(-1200.0, -3000.0, 13.0),   -- Exempelplats 6 (korrekt höjd)
}

-- ⚙️ Loot-belöningar
Config.LootRewards = {
    metalscrap = {
        minAmount = 1,  -- Minsta antal metalscrap
        maxAmount = 5   -- Högsta antal metalscrap
    },
    steel = {
        chance = 49,    -- 49% chans att få steel
        minAmount = 1,  -- Minsta antal steel
        maxAmount = 5   -- Högsta antal steel
    },
    copper = {
        chance = 25,    -- 25% chans att få copper
        minAmount = 1,  -- Minsta antal copper
        maxAmount = 3   -- Högsta antal copper
    },
    ironoxide = {
        chance = 50,    -- 50% chans att få ironoxide (om copper droppas)
        minAmount = 1,  -- Minsta antal ironoxide
        maxAmount = 1   -- Högsta antal ironoxide
    }
}

-- 🏆 **XP-belöningar baserat på rank**
Config.XPRewardByRank = {
    ["Rookie Smuggler"] = { min = 25, max = 40 },        -- Lägsta rank, lägst XP
    ["Street Supplier"] = { min = 40, max = 75 },       -- Högre rank, mer XP
    ["Gun Hustler"] = { min = 75, max = 125 },
    ["Black Market Trafficker"] = { min = 125, max = 180 },
    ["Weapon Broker"] = { min = 180, max = 300 },
    ["Cartel Associate"] = { min = 300, max = 360 },
    ["Underground Kingpin"] = { min = 360, max = 400 },
    ["Arms Syndicate Leader"] = { min = 400, max = 550 },
    ["Warlord"] = { min = 550, max = 610 },
    ["Black Market King"] = { min = 610, max = 700 }     -- Högsta rank, högst XP
}

-- ⚠️ **Uppdragsinställningar**
Config.MissionSettings = {
    allowMultipleMissions = false,  -- Tillåt inte flera aktiva uppdrag samtidigt
    missionActiveMessage = "Du har redan ett aktivt uppdrag!",  -- Meddelande om spelaren försöker starta ett nytt uppdrag
    missionCompleteMessage = "Uppdrag slutfört! Du fick %d XP och %s.",  -- Meddelande när uppdrag slutförs
    missionFailedMessage = "Uppdrag misslyckat!",  -- Meddelande om uppdrag misslyckas
}

-- 🎯 **Blip-inställningar**
Config.BlipSettings = {
    pickupBlip = {
        sprite = 568,  -- Blip-sprite för pickup
        color = 5,     -- Blip-färg för pickup
        scale = 0.8,   -- Blip-storlek för pickup
        label = "Pickup: Vapendelar"  -- Blip-beskrivning för pickup
    },
    dropoffBlip = {
        sprite = 501,  -- Blip-sprite för dropoff
        color = 2,     -- Blip-färg för dropoff
        scale = 0.8,   -- Blip-storlek för dropoff
        label = "Leverans: Vapendelar"  -- Blip-beskrivning för dropoff
    }
}

-- 🛠️ **Debug-inställningar**
Config.Debug = {
    enableDebugMessages = true,  -- Aktivera debug-meddelanden i konsolen
    debugPrefix = "[ArmsDealer]"  -- Prefix för debug-meddelanden
}

Config.UseCraftingZone = false

Config.CraftingZone = {
    coords = vector3(123.4, -321.5, 28.7), -- Byt till din verkstadsplats
    radius = 3.5
}

Config.CraftingRecipes = {
  { label = "Knife", item = "weapon_knife", requiredRankIndex = 1, xp = 15,
    materials = { metalscrap = 10 }, craftingTime = 4 },
  { label = "Switchblade", item = "weapon_switchblade", requiredRankIndex = 1, xp = 15,
    materials = { metalscrap = 10 }, craftingTime = 4 },
  { label = "Machete", item = "weapon_machete", requiredRankIndex = 1, xp = 20,
    materials = { metalscrap = 10 }, craftingTime = 4 },
  { label = "Dagger", item = "weapon_dagger", requiredRankIndex = 1, xp = 18,
    materials = { metalscrap = 10 }, craftingTime = 4 },
  { label = "Bat", item = "weapon_bat", requiredRankIndex = 1, xp = 20,
    materials = { metalscrap = 10 }, craftingTime = 4 },
  { label = "Pistol Ammo", item = "pistol_ammo", requiredRankIndex = 2, xp = 10,
    materials = { copper = 10, metalscrap = 10 }, craftingTime = 5 },
  { label = "Pistol", item = "weapon_pistol", requiredRankIndex = 3, xp = 30,
    materials = { steel = 15, metalscrap = 15 }, craftingTime = 6 },
  { label = "Snspistol", item = "weapon_snspistol", requiredRankIndex = 3, xp = 28,
    materials = { steel = 15, metalscrap = 15 }, craftingTime = 6 },
  { label = "Pistol Mk2", item = "weapon_pistol_mk2", requiredRankIndex = 3, xp = 32,
    materials = { steel = 15, metalscrap = 15 }, craftingTime = 6 },
  { label = "Vintagepistol", item = "weapon_vintagepistol", requiredRankIndex = 4, xp = 40,
    materials = { steel = 20, aluminumoxide = 10, metalscrap = 20 }, craftingTime = 7 },
  { label = "Ceramicpistol", item = "weapon_ceramicpistol", requiredRankIndex = 4, xp = 42,
    materials = { steel = 20, aluminumoxide = 10, metalscrap = 20 }, craftingTime = 7 },
  { label = "Stungun", item = "weapon_stungun", requiredRankIndex = 4, xp = 38,
    materials = { steel = 20, aluminumoxide = 10, metalscrap = 20 }, craftingTime = 7 },
  { label = "Revolver", item = "weapon_revolver", requiredRankIndex = 5, xp = 48,
    materials = { steel = 25, ironoxide = 10, aluminumoxide = 10, metalscrap = 25 }, craftingTime = 8 },
  { label = "Doubleaction", item = "weapon_doubleaction", requiredRankIndex = 5, xp = 46,
    materials = { steel = 25, ironoxide = 10, aluminumoxide = 10, metalscrap = 25 }, craftingTime = 8 },
  { label = "Pistol50", item = "weapon_pistol50", requiredRankIndex = 5, xp = 50,
    materials = { steel = 25, ironoxide = 10, aluminumoxide = 10, metalscrap = 25 }, craftingTime = 8 },
  { label = "Navyrevolver", item = "weapon_navyrevolver", requiredRankIndex = 5, xp = 52,
    materials = { steel = 25, ironoxide = 10, aluminumoxide = 10, metalscrap = 25 }, craftingTime = 8 },
  { label = "Smg Ammo", item = "smg_ammo", requiredRankIndex = 6, xp = 12,
    materials = { copper = 15, steel = 20, metalscrap = 25 }, craftingTime = 6 },
  { label = "Microsmg", item = "weapon_microsmg", requiredRankIndex = 7, xp = 65,
    materials = { steel = 35, copper = 20, aluminumoxide = 15, metalscrap = 35 }, craftingTime = 8 },
  { label = "Smg", item = "weapon_smg", requiredRankIndex = 7, xp = 65,
    materials = { steel = 35, copper = 20, aluminumoxide = 15, metalscrap = 35 }, craftingTime = 8 },
  { label = "Smg Mk2", item = "weapon_smg_mk2", requiredRankIndex = 7, xp = 68,
    materials = { steel = 35, copper = 20, aluminumoxide = 15, metalscrap = 35 }, craftingTime = 8 },
  { label = "Assaultsmg", item = "weapon_assaultsmg", requiredRankIndex = 8, xp = 75,
    materials = { steel = 45, copper = 25, ironoxide = 15, aluminumoxide = 20, metalscrap = 40 }, craftingTime = 10 },
  { label = "Minismg", item = "weapon_minismg", requiredRankIndex = 8, xp = 72,
    materials = { steel = 45, copper = 25, ironoxide = 15, aluminumoxide = 20, metalscrap = 40 }, craftingTime = 10 },
  { label = "Rifle Ammo", item = "rifle_ammo", requiredRankIndex = 9, xp = 20,
    materials = { steel = 55, copper = 30, ironoxide = 25, aluminumoxide = 25, metalscrap = 45 }, craftingTime = 12 },
  { label = "Assaultrifle", item = "weapon_assaultrifle", requiredRankIndex = 9, xp = 85,
    materials = { steel = 55, copper = 30, ironoxide = 25, aluminumoxide = 25, metalscrap = 45 }, craftingTime = 12 },
  { label = "Carbinerifle", item = "weapon_carbinerifle", requiredRankIndex = 9, xp = 85,
    materials = { steel = 55, copper = 30, ironoxide = 25, aluminumoxide = 25, metalscrap = 45 }, craftingTime = 12 },
  { label = "Specialcarbine", item = "weapon_specialcarbine", requiredRankIndex = 9, xp = 90,
    materials = { steel = 55, copper = 30, ironoxide = 25, aluminumoxide = 25, metalscrap = 45 }, craftingTime = 12 },
  { label = "Sniperrifle", item = "weapon_sniperrifle", requiredRankIndex = 10, xp = 130,
    materials = { steel = 80, copper = 35, ironoxide = 35, aluminumoxide = 35, metalscrap = 60 }, craftingTime = 14 },
  { label = "Heavysniper", item = "weapon_heavysniper", requiredRankIndex = 10, xp = 135,
    materials = { steel = 80, copper = 35, ironoxide = 35, aluminumoxide = 35, metalscrap = 60 }, craftingTime = 14 },
  { label = "Militaryrifle", item = "weapon_militaryrifle", requiredRankIndex = 10, xp = 125,
    materials = { steel = 80, copper = 35, ironoxide = 35, aluminumoxide = 35, metalscrap = 60 }, craftingTime = 14 },
}

-- 🔫 SMUGGLING CONFIGURATION ---------------------------------------------

Config.SmugglingHeist = {
  CarModel = "rebel",
  Locations = {
      {
          car = vector3(1274.16, -3238.63, 5.9),
          heading = 90.0,
          npcs = {
              {
                  model = `g_m_m_armboss_01`,
                  weapon = GetHashKey("weapon_pistol"),
                  pos = vector3(1280.47, -3246.1, 5.9),
                  heading = 270.0
              },
              {
                  model = `g_m_m_armgoon_01`,
                  weapon = GetHashKey("weapon_smg"),
                  pos = vector3(1270.0, -3242.5, 5.9),
                  heading = 270.0
              }
          }
      }
  },
  ActiveSmugglers = {}
}

Config.USBMission = {
  location = vector3(145.3, -2201.6, 4.8),
  npcPositions = {
      vector3(126.76, -2201.56, 6.03),
      vector3(144.06, -2186.58, 5.95),
      vector3(143.73, -2184.61, 15.88),
      vector3(161.98, -2207.84, 13.85),
      vector3(142.94, -2201.07, 4.69),
      vector3(149.77, -2203.8, 4.69)
  },
  npcModel = "g_m_m_armboss_01",
  npcWeapon = "weapon_smg",
  tiedNpcModel = "cs_bankman",
  tiedNpcPos = vector4(145.3, -2201.6, 4.8, 270.0),
  armoryPos = vector4(-186.38, -1085.28, 21.69, 322.55),
  armoryBlipText = "Armory Station"
}

-- 🔫 XP-belöning per dödad NPC i smuggling
Config.SmugglingXPPerKill = { min = 15, max = 75 }

-- 🏭 STRID I LAGERLOKAL
Config.WarehouseCombat = {
  location = vector3(930.1, -2100.2, 30.7),
  enemyModel = "g_m_y_mexgoon_02",
  enemyWeapon = "weapon_assaultrifle",
  enemyPositions = {
      vector3(927.5, -2103.1, 30.7),
      vector3(932.6, -2105.4, 30.7),
      vector3(934.2, -2100.9, 30.7),
      vector3(937.5, -2098.2, 30.7),
      vector3(938.6, -2103.3, 30.7),
      vector3(935.1, -2095.7, 30.7),
      vector3(931.3, -2095.2, 30.7),
      vector3(928.4, -2097.8, 30.7),
      vector3(926.8, -2100.0, 30.7),
      vector3(930.0, -2104.8, 30.7)
  }
}

-- 📦 VAPENLÅDA & FÖRSTA GAFFELTRUCKEN
Config.WeaponCrate = {
  model = "prop_box_wood02a_pu",
  pos = vector3(930.5, -2101.5, 30.7),
  forkliftModel = "forklift",
  forkliftSpawn = vector3(933.2, -2107.2, 30.7),
  forkliftHeading = 270.0
}

-- 📦 LEVERANSPLATS & AVLASTNING
Config.LootDelivery = {
  garagePos = vector3(1096.5, -2007.0, 31.4),
  forkliftModel = "forklift",
  forkliftSpawn = vector3(1095.0, -2004.5, 31.4),
  forkliftHeading = 90.0,
  dropZone = vector3(1092.0, -2006.0, 31.4)
}

-- 🎁 LOOTREWARDS – SLUMPMÄSSIG BELÖNING BASERAD PÅ PROCENT
Config.LootRewards = {
  { item = "weapon_pistol", chance = 50 },
  { item = "weapon_smg", chance = 30 },
  { item = "weapon_assaultrifle", chance = 10 },
  { item = "weapon_militaryrifle", chance = 5 },
  { item = "weapon_knife", chance = 10 },
  { item = "armor", chance = 20 }
}






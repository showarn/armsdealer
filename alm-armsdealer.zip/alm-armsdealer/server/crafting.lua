local QBCore = exports['qb-core']:GetCoreObject()

function GetPlayerRankIndex(xp)
    for i = #Config.RankThresholds, 1, -1 do
        if xp >= Config.RankThresholds[i].xp then
            return i
        end
    end
    return 1
end

RegisterNetEvent("armsdealer:server:completeCraft", function(recipeIndex)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local recipe = Config.CraftingRecipes[recipeIndex]

    if not Player or not recipe then return end

    local xp = Player.Functions.GetMetaData("armsdealer_xp") or 0
    local rankIndex = GetPlayerRankIndex(xp)

    if rankIndex < recipe.requiredRankIndex then
        print("[CRAFTING FUSK] Spelare", src, "försökte crafta utan rätt rank")
        return
    end

    -- Kolla material
    for item, amount in pairs(recipe.materials) do
        local invAmount = Player.Functions.GetItemByName(item)?.amount or 0
        if invAmount < amount then
            TriggerClientEvent('QBCore:Notify', src, "Du saknar material för " .. recipe.label, "error")
            return
        end
    end

    -- Dra material
    for item, amount in pairs(recipe.materials) do
        Player.Functions.RemoveItem(item, amount)
    end

    -- Ge belöning
    Player.Functions.AddItem(recipe.item, 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[recipe.item], "add")
    TriggerClientEvent('QBCore:Notify', src, "Du tillverkade: " .. recipe.label, "success")

    -- ✅ Ge XP efter crafting
    local xpReward = recipe.xp or 20 -- fallback om xp saknas i config
    TriggerEvent('qb-armsdealer:server:AddXP', src, xpReward)    
end)
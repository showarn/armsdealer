-- 📂 server/main.lua (Rensad från XP-system)
QBCore = exports['qb-core']:GetCoreObject()

-- Ladda in data från config.lua
local PartPickupLocations = Config.PartPickupLocations
local PartDropoffLocations = Config.PartDropoffLocations
local jobName = Config.JobName or "armsdealer"
local LootBonusPerRank = Config.LootBonusPerRank

-- 🏆 Kommando för att öppna Arms Dealer-menyn med XP & Rank
RegisterCommand("armsdealer", function(source, args, rawCommand)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player and Player.PlayerData.job.name == jobName then
        local xp = Player.Functions.GetMetaData("armsdealer_xp") or 0
        local rank = GetPlayerRank(xp) -- ✅ Nu från server/expsystem.lua
        TriggerClientEvent('qb-armsdealer:openArmsDealerMenu', source, xp, rank)
    else
        TriggerClientEvent('QBCore:Notify', source, 'Du är inte en Arms Dealer!', 'error')
    end
end, false)

-- 🚚 StartPartRun - Slumpa en pickup-plats
RegisterNetEvent('alm-armsdealer:server:StartPartRun', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= jobName then
        TriggerClientEvent('QBCore:Notify', src, "Du är inte en Arms Dealer!", "error")
        return
    end
    local randomIndex = math.random(#PartPickupLocations)
    local chosenCoord = PartPickupLocations[randomIndex]
    TriggerClientEvent('alm-armsdealer:client:SetPickupLocation', src, chosenCoord)
    TriggerClientEvent('QBCore:Notify', src, "En pickup-plats har markerats på din karta!", "success")
end)

-- 📦 PickupPart - Hanterar pickup och eventuell polisvarning
RegisterNetEvent('alm-armsdealer:server:PickupPart', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= jobName then return end

    if math.random(1, 2) == 1 then
        local players = QBCore.Functions.GetPlayers()
        for _, policeSrc in pairs(players) do
            local PolicePlayer = QBCore.Functions.GetPlayer(policeSrc)
            if PolicePlayer and PolicePlayer.PlayerData.job.name == "police" then
                TriggerClientEvent('alm-armsdealer:client:PoliceAlert', policeSrc, GetEntityCoords(GetPlayerPed(src)))
                TriggerClientEvent('QBCore:Notify', policeSrc, "Misstänkt aktivitet upptäckt nära en pickup-plats!", "error")
            end
        end
    end

    local dropoffIndex = math.random(#PartDropoffLocations)
    local dropoffCoord = PartDropoffLocations[dropoffIndex]
    TriggerClientEvent('alm-armsdealer:client:SetDropoffLocation', src, dropoffCoord)
    TriggerClientEvent('QBCore:Notify', src, "Leverera vapendelar till markerad plats!", "primary")
end)

-- 🏆 CompleteRun - När spelaren levererar vapendelar
RegisterNetEvent('alm-armsdealer:server:CompleteRun', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= jobName then return end

    local xp = Player.Functions.GetMetaData("armsdealer_xp") or 0
    local rank = GetPlayerRank(xp)
    local rankIndex = GetPlayerRankIndex(xp)
    local bonusChance = rankIndex * Config.LootBonusPerRank
    local rewards = {}

    local metalscrapAmount = math.random(Config.LootRewards.metalscrap.minAmount, Config.LootRewards.metalscrap.maxAmount)
    Player.Functions.AddItem('metalscrap', metalscrapAmount)
    table.insert(rewards, { item = 'metalscrap', amount = metalscrapAmount })

    if math.random(1, 100) <= Config.LootRewards.steel.chance + bonusChance then
        local amt = math.random(Config.LootRewards.steel.minAmount, Config.LootRewards.steel.maxAmount)
        Player.Functions.AddItem('steel', amt)
        table.insert(rewards, { item = 'steel', amount = amt })
    end

    if math.random(1, 100) <= Config.LootRewards.copper.chance + bonusChance then
        local amt = math.random(Config.LootRewards.copper.minAmount, Config.LootRewards.copper.maxAmount)
        Player.Functions.AddItem('copper', amt)
        table.insert(rewards, { item = 'copper', amount = amt })

        if math.random(1, 100) <= Config.LootRewards.ironoxide.chance then
            local amt2 = math.random(Config.LootRewards.ironoxide.minAmount, Config.LootRewards.ironoxide.maxAmount)
            Player.Functions.AddItem('ironoxide', amt2)
            table.insert(rewards, { item = 'ironoxide', amount = amt2 })
        end
    end

    local xpReward = math.random(Config.XPRewardByRank[rank].min, Config.XPRewardByRank[rank].max)
    TriggerEvent('qb-armsdealer:server:AddXP', src, xpReward)

    local newRank = GetPlayerRank(xp + xpReward)
    if newRank ~= rank then
        TriggerClientEvent('QBCore:Notify', src, "Du har rankat upp till " .. newRank .. "!", "success")
    end

    TriggerClientEvent('alm-armsdealer:client:ShowRewardNotification', src, rewards)
    TriggerClientEvent('alm-armsdealer:client:RemoveBackpack', src)
end)

RegisterNetEvent("armsdealer:server:openCrafting", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local xp = Player.Functions.GetMetaData("armsdealer_xp") or 0
    TriggerClientEvent("armsdealer:client:openCrafting", src, xp)
end)
-- 🔧 SERVER: Smuggling Heist Logic (optimerad)

local QBCore = exports['qb-core']:GetCoreObject()
local jobName = Config.JobName or "armsdealer"

-- 🔐 Aktiva smugglare per session
Config.SmugglingHeist.ActiveSmugglers = Config.SmugglingHeist.ActiveSmugglers or {}

-- 🔫 Starta smuggeluppdrag (via menyknapp)
RegisterNetEvent("armsdealer:server:startSmuggleHeist", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= jobName then return end

    -- Hindra flera samtidiga uppdrag
    if Config.SmugglingHeist.ActiveSmugglers[src] then return end
    Config.SmugglingHeist.ActiveSmugglers[src] = true

    local heist = Config.SmugglingHeist.Locations[1]
    local data = {
        carPos = heist.car,
        carHeading = heist.heading,
        npcs = heist.npcs
    }

    TriggerClientEvent("smuggling:client:startHeist", src, data)
end)

-- ✅ Kontroll: ska NPC attackera denna spelare?
RegisterNetEvent("smuggling:server:checkSmugglerStatus", function()
    local src = source
    if Config.SmugglingHeist.ActiveSmugglers[src] then
        TriggerClientEvent("smuggling:client:triggerAttack", src)
    end
end)

-- 🧠 XP vid NPC-kill
RegisterNetEvent("smuggling:server:RewardKillXP", function()
    local src = source
    local amount = math.random(Config.SmugglingXPPerKill.min, Config.SmugglingXPPerKill.max)
    TriggerEvent("qb-armsdealer:server:AddXP", src, amount)
    TriggerClientEvent("smuggling:client:ShowXPReward", src, amount)
end)

-- 📦 Ge belöning i slutet
RegisterNetEvent("smuggling:server:GiveLootReward", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local rewards = {}
    for _, item in pairs(Config.SmugglingLootTable) do
        if math.random(100) <= item.chance then
            Player.Functions.AddItem(item.name, item.amount)
            table.insert(rewards, (item.amount > 1 and item.amount .. "x " or "") .. QBCore.Shared.Items[item.name].label)
        end
    end

    TriggerClientEvent("smuggling:client:ReceiveLoot", src, rewards)
    Config.SmugglingHeist.ActiveSmugglers[src] = nil
end)

-- ❌ Rensa om spelare loggar ut eller kraschar
AddEventHandler("playerDropped", function()
    local src = source
    Config.SmugglingHeist.ActiveSmugglers[src] = nil
end)

-- 🛑 Rensa uppdrag manuellt
RegisterNetEvent("smuggling:server:endHeist", function()
    local src = source
    Config.SmugglingHeist.ActiveSmugglers[src] = nil
    TriggerClientEvent("smuggling:client:forceAbortHeist", src)
end)
-- 📂 server/expsystem.lua
local QBCore = exports['qb-core']:GetCoreObject()
local RankThresholds = Config.RankThresholds

-- 🔢 Returnerar rankens label baserat på spelarens XP
function GetPlayerRank(xp)
    for i = #RankThresholds, 1, -1 do
        if xp >= RankThresholds[i].xp then
            return RankThresholds[i].rank
        end
    end
    return RankThresholds[1].rank
end

-- 🔢 Returnerar index för spelarens nuvarande rank (används för loot, crafting, mm.)
function GetPlayerRankIndex(xp)
    for i = #RankThresholds, 1, -1 do
        if xp >= RankThresholds[i].xp then
            return i
        end
    end
    return 1
end

-- 🧠 Serverfunktion för att lägga till XP och uppdatera klienten
RegisterNetEvent('qb-armsdealer:server:AddXP', function(playerId, amount)
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then return end

    local currentXP = Player.Functions.GetMetaData("armsdealer_xp") or 0
    local newXP = currentXP + amount

    Player.Functions.SetMetaData("armsdealer_xp", newXP)

    local newRank = GetPlayerRank(newXP)

    -- 🔔 Uppdatera klienten med ny XP och rank
    TriggerClientEvent('qb-armsdealer:client:SetXP', playerId, newXP, newRank)
    TriggerClientEvent('QBCore:Notify', playerId, "Du har fått " .. amount .. " XP!", "success")
end)

-- 📂 shared/rankutils.lua

function GetPlayerRank(xp)
  for i = #Config.RankThresholds, 1, -1 do
      if xp >= Config.RankThresholds[i].xp then
          return Config.RankThresholds[i].rank
      end
  end
  return Config.RankThresholds[1].rank
end

function GetPlayerRankIndex(xp)
  for i = #Config.RankThresholds, 1, -1 do
      if xp >= Config.RankThresholds[i].xp then
          return i
      end
  end
  return 1
end
